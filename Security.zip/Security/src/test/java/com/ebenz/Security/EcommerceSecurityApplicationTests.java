package com.ebenz.Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
