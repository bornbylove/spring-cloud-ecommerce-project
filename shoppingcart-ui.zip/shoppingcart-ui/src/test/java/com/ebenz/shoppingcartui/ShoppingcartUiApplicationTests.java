package com.ebenz.shoppingcartui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingcartUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
