package com.ebenz.DynaTraceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynaTraceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynaTraceServerApplication.class, args);
	}

}
